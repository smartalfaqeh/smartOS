# Mulakan SmartOS secara automatik pada konsol pertama
if [ -z "$WAYLAND_DISPLAY" ] && [ "$(tty)" = "/dev/tty1" ]; then
  exec cage -s -- /opt/smartos/bin/smartos-session
fi
